//
//  AppBoxoSDK.h
//  AppBoxoSDK
//
//  Created by KubaRahmetMobile on 12/19/19.
//  Copyright © 2019 AppBoxo. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AppBoxoSDK.
FOUNDATION_EXPORT double AppBoxoSDKVersionNumber;

//! Project version string for AppBoxoSDK.
FOUNDATION_EXPORT const unsigned char AppBoxoSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AppBoxoSDK/PublicHeader.h>


